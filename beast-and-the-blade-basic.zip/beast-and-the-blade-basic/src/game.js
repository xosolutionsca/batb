// Beast & the Blade — ultra-basic browser prototype
// No libraries, just Canvas 2D. Designed to run on GitHub Pages.
// Author: ChatGPT (for Loren)

(function () {
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const ui = {
    hp: document.getElementById("health"),
    sta: document.getElementById("stamina"),
    score: document.getElementById("score"),
  };

  // Resize handling
  function resize() {
    const dpr = Math.max(1, Math.floor(window.devicePixelRatio || 1));
    canvas.width = Math.floor(window.innerWidth * dpr);
    canvas.height = Math.floor(window.innerHeight * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    vw = window.innerWidth;
    vh = window.innerHeight;
  }
  window.addEventListener("resize", resize);

  // Game state
  let vw = window.innerWidth, vh = window.innerHeight;
  resize();
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const dist2 = (a, b) => {
    const dx = a.x - b.x; const dy = a.y - b.y;
    return dx*dx + dy*dy;
  };

  const input = { w:false,a:false,s:false,d:false,shift:false,mouse:false, mx:0,my:0, pause:false };
  window.addEventListener("keydown", (e) => {
    if (e.repeat) return;
    if (e.key === "w" || e.key === "W") input.w = true;
    if (e.key === "a" || e.key === "A") input.a = true;
    if (e.key === "s" || e.key === "S") input.s = true;
    if (e.key === "d" || e.key === "D") input.d = true;
    if (e.key === "Shift") input.shift = true;
    if (e.key === "p" || e.key === "P") input.pause = !input.pause;
  });
  window.addEventListener("keyup", (e) => {
    if (e.key === "w" || e.key === "W") input.w = false;
    if (e.key === "a" || e.key === "A") input.a = false;
    if (e.key === "s" || e.key === "S") input.s = false;
    if (e.key === "d" || e.key === "D") input.d = false;
    if (e.key === "Shift") input.shift = false;
  });
  canvas.addEventListener("mousedown", () => input.mouse = true);
  canvas.addEventListener("mouseup", () => input.mouse = false);
  canvas.addEventListener("mousemove", (e) => { input.mx = e.clientX; input.my = e.clientY; });

  // Entities
  const player = {
    x: vw/2, y: vh/2, r: 16,
    speed: 220, dashSpeed: 360,
    color: "#e8f1c8",
    hp: 100, sta: 100, maxSta: 100,
    attackCd: 0, dashCd: 0, invuln: 0,
  };

  const enemies = [];
  const pickups = [];
  let score = 0;
  let spawnTimer = 0;

  function spawnEnemy() {
    // spawn at edges
    const edge = Math.floor(Math.random()*4);
    let x=0, y=0;
    if (edge === 0) { x = Math.random()*vw; y = -40; }
    if (edge === 1) { x = Math.random()*vw; y = vh+40; }
    if (edge === 2) { x = -40; y = Math.random()*vh; }
    if (edge === 3) { x = vw+40; y = Math.random()*vh; }
    enemies.push({
      x, y, r: 14, hp: 20,
      speed: 90 + Math.random()*40,
      color: "#9cf0c2",
      hitflash: 0
    });
  }

  function spawnPickup(x,y) {
    pickups.push({ x, y, r: 8, type: (Math.random()<0.6?"heal":"stamina") });
  }

  // Grass background (procedural tiles)
  function drawGrass() {
    const size = 32;
    ctx.save();
    ctx.fillStyle = "#233023"; // dark base
    ctx.fillRect(0,0,vw,vh);
    for (let y=0; y<vh+size; y+=size) {
      for (let x=0; x<vw+size; x+=size) {
        const g = 50 + ((x*31 + y*17) % 50);
        ctx.fillStyle = `rgb(${20+g*0.2}, ${60+g}, ${20+g*0.3})`;
        ctx.fillRect(x, y, size, size);
      }
    }
    ctx.restore();
  }

  function drawCircle(x,y,r, color, stroke=false) {
    ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2);
    if (stroke) { ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke(); }
    else { ctx.fillStyle = color; ctx.fill(); }
  }

  function movePlayer(dt) {
    let vx=0, vy=0;
    if (input.w) vy -= 1;
    if (input.s) vy += 1;
    if (input.a) vx -= 1;
    if (input.d) vx += 1;
    const len = Math.hypot(vx, vy) || 1;
    vx /= len; vy /= len;

    const dash = input.shift && player.sta > 0;
    const spd = dash ? player.dashSpeed : player.speed;
    player.x = clamp(player.x + vx*spd*dt, 0+player.r, vw-player.r);
    player.y = clamp(player.y + vy*spd*dt, 0+player.r, vh-player.r);
    if (dash) player.sta = Math.max(0, player.sta - 30*dt);
    else player.sta = Math.min(player.maxSta, player.sta + 20*dt);
  }

  function angleToMouse(px,py) {
    const dx = input.mx - px;
    const dy = input.my - py;
    return Math.atan2(dy, dx);
  }

  // attack detection: simple arc in front of player
  let attackTimer = 0;
  function handleAttack(dt) {
    if (player.attackCd > 0) player.attackCd -= dt;
    if (input.mouse && player.attackCd <= 0) {
      attackTimer = 0.18; // duration of swing
      player.attackCd = 0.35;
    }
    if (attackTimer > 0) {
      attackTimer -= dt;
      // detect enemies in arc
      const ang = angleToMouse(player.x, player.y);
      const radius = 60;
      const arc = Math.PI * 0.9;
      enemies.forEach((e) => {
        const a = Math.atan2(e.y - player.y, e.x - player.x);
        let da = Math.atan2(Math.sin(a-ang), Math.cos(a-ang)); // shortest angle
        const d2 = dist2(player, e);
        if (Math.abs(da) < arc*0.5 && d2 < (radius*radius)) {
          e.hp -= 10;
          e.hitflash = 0.1;
          if (e.hp <= 0) {
            score += 10;
            spawnPickup(e.x, e.y);
          }
        }
      });
    }
  }

  function updateEnemies(dt) {
    for (let i=enemies.length-1; i>=0; --i) {
      const e = enemies[i];
      const dx = player.x - e.x;
      const dy = player.y - e.y;
      const len = Math.hypot(dx, dy) || 1;
      const ux = dx/len, uy = dy/len;
      e.x += ux * e.speed * dt;
      e.y += uy * e.speed * dt;
      if (e.hitflash > 0) e.hitflash -= dt;

      // collide with player
      const rr = (player.r + e.r);
      if (dist2(player, e) < rr*rr) {
        if (player.invuln <= 0) {
          player.hp -= 8;
          player.invuln = 0.6;
        }
      }

      if (e.hp <= 0) enemies.splice(i,1);
    }
    if (player.invuln > 0) player.invuln -= dt;
  }

  function updatePickups(dt) {
    for (let i=pickups.length-1; i>=0; --i) {
      const p = pickups[i];
      const rr = (player.r + p.r);
      if (dist2(player, p) < rr*rr) {
        if (p.type === "heal") player.hp = clamp(player.hp + 15, 0, 100);
        if (p.type === "stamina") player.sta = clamp(player.sta + 30, 0, player.maxSta);
        pickups.splice(i,1);
      }
    }
  }

  function draw() {
    drawGrass();

    // draw pickups
    pickups.forEach(p => {
      drawCircle(p.x, p.y, p.r, p.type === "heal" ? "#ffb3ba" : "#bae1ff");
    });

    // draw enemies
    enemies.forEach(e => {
      const c = e.hitflash > 0 ? "#ffffff" : e.color;
      drawCircle(e.x, e.y, e.r, c);
    });

    // draw player
    const pc = player.invuln > 0 ? "#ffd26e" : player.color;
    drawCircle(player.x, player.y, player.r, pc);
    // sword arc feedback
    if (attackTimer > 0) {
      const ang = angleToMouse(player.x, player.y);
      const radius = 60;
      ctx.beginPath();
      ctx.arc(player.x, player.y, radius, ang - Math.PI*0.45, ang + Math.PI*0.45);
      ctx.strokeStyle = "#f5f5f5";
      ctx.lineWidth = 3;
      ctx.stroke();
    }

    // UI
    ui.hp.textContent = "HP: " + Math.max(0, Math.floor(player.hp));
    ui.sta.textContent = "STA: " + Math.max(0, Math.floor(player.sta));
    ui.score.textContent = "Score: " + score;
  }

  // Main loop
  let last = performance.now();
  function loop(now) {
    const dt = Math.min(0.033, (now - last) / 1000);
    last = now;
    if (!input.pause && player.hp > 0) {
      movePlayer(dt);
      handleAttack(dt);
      updateEnemies(dt);
      updatePickups(dt);
      spawnTimer -= dt;
      if (spawnTimer <= 0) {
        spawnEnemy();
        spawnTimer = Math.max(0.3, 1.2 - score * 0.003); // harder over time
      }
    }
    draw();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();