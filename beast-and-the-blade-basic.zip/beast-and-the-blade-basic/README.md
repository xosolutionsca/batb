# Beast & the Blade — Basic (Browser Edition)

A tiny, dependency-free browser game you can host on **GitHub Pages**.  
Move with **WASD**, **Dash** with Shift, **Attack** with left click, **Pause** with `P`.

> This is a minimal prototype so you can have a working “game” repo immediately.  
> Later, you can replace it with Unreal Engine builds and still keep this as a playable demo page.

## Run locally
Just open `index.html` in a modern browser. No build step required.

## Deploy on GitHub Pages
1. Create a **new GitHub repository** named `beast-and-the-blade-basic` (public is fine).
2. Upload all files in this folder to the repo root (or push via Git).
3. In the GitHub repo, go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source = Deploy from a branch**.
5. Set **Branch = main** and **Folder = /(root)**. Save.
6. GitHub will give you a Pages URL like `https://<yourname>.github.io/beast-and-the-blade-basic/`.

## Suggested next steps
- Add sprites / art to `assets/`
- Add more enemies, boss, parry window, damage numbers
- Replace procedural grass with tiles or a painted background
- Port mechanics into Unreal Engine when ready

## License
MIT
